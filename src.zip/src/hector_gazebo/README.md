hector_gazebo
=============

hector_gazebo provides packages related to the simulation of robots using gazebo (gazebo plugins, world files etc.).
