import gym


env = gym.make("PhantomX-v0")



obs = env.reset()
done = False
while not done:
    action = env.action_space.sample()
    obs, reward, done, _ = env.step(action)
    print(f"Action: {action}, Reward: {reward}, Done: {done}")


from gym.envs.registration import register

register(
    id='PhantomX-v0',
    entry_point='phantomx_env:PhantomXEnv',
)

